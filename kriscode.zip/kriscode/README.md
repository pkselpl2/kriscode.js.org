# KrisCode

KrisCode는 블록 기반 코딩과 JavaScript 실행을 결합한
웹 기반 코딩 플랫폼입니다.

## 목표
- 엔트리 느낌의 블록 코딩
- 블록 → JavaScript 변환
- 브라우저에서 바로 실행

## 개발자
- 크리스팀
